function y=h(x)
y=x^2-4;
end