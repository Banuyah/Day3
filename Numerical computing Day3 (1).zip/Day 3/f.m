function y=f(x)
y=x^2-4;
end